export const post = [
  {
    image: "https://via.placeholder.com/500x330",
    title: "5 DIY tips to use in kitchen",
    date: "28 Oct, 2016",
    description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt."
  },
  {
    image: "https://via.placeholder.com/500x330",
    title: "It allowance prevailed",
    date: "20 Sept, 2016",
    description: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. "
  },
  {
    image: "https://via.placeholder.com/500x330",
    title: "Case read they must",
    date: "14 Aug, 2016",
    description: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form"
  },
  {
    image: "https://via.placeholder.com/500x330",
    title: "Too carriage attended",
    date: "28 July, 2016",
    description: "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC"
  },
];
