export default [
  {
    'id': 1,
    'notes': 'Id nulla nulla proident deserunt deserunt proident in quis. Cillum reprehenderit labore id anim laborum.',
    'selected': false,
  },
  {
    'id': 2,
    'notes': 'Magna quis irure quis ea pariatur laborum',
    'selected': false,
  },
  {
    'id': 3,
    'notes': 'Sunt laborum enim nostrud ea fugiat cillum mollit aliqua exercitation ad elit.',
    'selected': false,
  },
  {
    'id': 4,
    'notes': 'Nostrud anim mollit incididunt qui qui sit commodo duis. Anim amet irure aliquip duis nostrud sit quis fugiat ullamco non dolor labore. Lorem sunt voluptate laboris culpa proident. Aute eiusmod aliqua exercitation irure exercitation qui laboris mollit occaecat eu occaecat fugiat.',
    'selected': false,
  },
  {
    'id': 5,
    'notes': 'Velit ipsum proident ea incididunt et. Consectetur eiusmod laborum voluptate duis occaecat ullamco sint enim proident.',
    'selected': false,
  },
  {
    'id': 6,
    'notes': 'Esse nisi mollit aliquip mollit aute consequat adipisicing. Do excepteur dolore proident cupidatat pariatur irure consequat incididunt.',
    'selected': false,
  },
]