const styles = {
    card: {
      maxWidth: 345,
      margin: 20
    },
    media: {
      height: 200,
    }
    ,
  }
;
export default styles;