import React from 'react';

const RecentActivity = () => {
  return (
    <div className="jr-card">
      <div className="jr-card-header">
        Recent Activities
      </div>
      <p className="text-muted">last activity was two days ago</p>

    </div>
  )
};

export default RecentActivity;

