import React from 'react';
import TestComponent from 'app/routes/calendar/routes/basic';
import 'react-big-calendar/lib/less/styles.less';
import 'styles/app.scss';


const Test = () => {
  return (
    <TestComponent/>
  );
};

export default Test;